import React from 'react';
import { View, Text, Image, ScrollView, TextInput } from 'react-native';

const App = () => {
  return (
    <ScrollView>
      <Text style={{ fontSize: 20, fontWeight: 'bold', textAlign: 'center' }}>
        My name is Christian
      </Text>
      
      <View style={{ alignItems: 'center' }}>
        <Image
          source={{
            uri: 'https://4kwallpapers.com/images/walls/thumbs_3t/20507.png',
          }}
          style={{ width: 500, height: 500 }}
        />
      </View>
      
      <TextInput
        style={{
          height: 50,
          borderColor: 'red',
          borderWidth: 1,
        }}
        style={{
          height: 20,
          textAlign: 'center'
        }}  
        defaultValue="You can type in me"
      />
    </ScrollView>
  );
};

export default App;
