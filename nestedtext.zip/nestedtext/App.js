import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { SafeAreaView, SafeAreaProvider } from 'react-native-safe-area-context';

const BoldAndBeautiful = () => (
  <SafeAreaProvider>
    <SafeAreaView style={styles.container}>
      <Text style={styles.baseText}>i am Christian Guillermo </Text>
      <Text style={styles.innerText}>i am currenly talking BSIT </Text>
            <Text style={styles.baseText}>i am on Global Reciprocal College</Text>
             <Text style={styles.innerText}>my dream is programmer.</Text>


    </SafeAreaView>
  </SafeAreaProvider>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  baseText: {
    fontWeight: 'bold',
  },
  innerText: {
    color: 'red',
  },
});

export default BoldAndBeautiful;
